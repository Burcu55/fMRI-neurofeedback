# Preprocessing pipeline for fMRI data
