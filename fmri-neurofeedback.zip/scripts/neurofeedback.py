# Neurofeedback control logic
