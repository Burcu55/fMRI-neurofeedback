import time
import numpy as np
import matplotlib.pyplot as plt

def simulate_brain_activity(duration=60, sampling_rate=1):
    """Simulate fMRI signal from a target ROI."""
    t = np.linspace(0, duration, int(duration * sampling_rate))
    signal = np.sin(0.2 * t) + np.random.normal(0, 0.1, len(t))
    return t, signal

def provide_feedback(signal):
    """Provide visual neurofeedback based on signal strength."""
    for i, value in enumerate(signal):
        print(f"Time {i}: ROI activation = {value:.2f}")
        if value > 0.5:
            print("↑ Increase focus!")
        elif value < -0.5:
            print("↓ Relax!")
        else:
            print("→ Maintain...")
        time.sleep(0.2)  # simulate real-time pacing

if __name__ == "__main__":
    t, signal = simulate_brain_activity()
    provide_feedback(signal)
